package com.company;

public class Java_02_Operators {
    public static void main(String[] args) {
        int a = 4;
        a++;

        //Arithmetic Operators (%,/,*,+,-,++,--)
        // Modulo operator
        System.out.println(a);
        // Assignment operators(+=,-=,=)
//        int b = 3;
//        b +=3;
//        System.out.println(b);
        //Comparison operators (==,<=,>=)
        System.out.println(3==5);
        //Logical opertors(&&,||)
        System.out.println(64>45 && 45>56);
        //Bitwise operators(&,|)
        System.out.println(9&3);

    }
}
