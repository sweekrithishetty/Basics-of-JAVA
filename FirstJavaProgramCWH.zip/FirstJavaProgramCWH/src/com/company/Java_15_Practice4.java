package com.company;
import java.util.Scanner;
public class Java_15_Practice4 {
    public static void main(String[] args) {
//        int a = 4;
//        int b = 5;
//        int c = 7;
//        int sum = a+b+c;
//        System.out.println(sum);
        //question 2
//        int sub1 = 45;
//        int sub2 = 55;
//        int sub3 = 65;
//        float sum = (sub1+sub2+sub3)/30;
//        System.out.println("CGPA: "+sum);
        //question 3
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter your name");
//        String s1 = sc.nextLine();
//        System.out.println("Hello " + s1 + " have a good day!");
//        question 4
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter number for conversion");
//        float f1 = sc.nextFloat();
//        double s1;
//        s1 = (f1)/1.609;
//        System.out.println("Conversion is:"+ s1);
        //question4
          Scanner sc = new Scanner(System.in);
        System.out.println("check");
          boolean s1 = sc.hasNextInt();
        System.out.println(s1);








    }
}
