package com.company;

public class Java_11_Conditonal {
    public static void main(String[] args) {
        int a = 29;
        if (a>18) {
            System.out.println("You can drive");
        }
        else{
            System.out.println("You cannot drive");

        }


    }
}
