package com.company;

public class Java_04_Literals {
    public static void main(String[] args) {
        byte age  = 3;
        char ch1  = 'A';
        int  age2 = 67;
        float f1 = 4.0f;
        double d1 = 4.0D;
        boolean b1 = true;
        long agedinoo = 222222222L;
        System.out.println(f1);
        String str = "Hello00";
        System.out.println(str);

    }
}
