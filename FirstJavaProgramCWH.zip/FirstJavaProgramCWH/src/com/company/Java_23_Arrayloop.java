package com.company;

public class Java_23_Arrayloop {
    public static void main(String[] args) {
        int [] marks = {22,56,77,88,99,23};
       // float [] marks = {22,56,77,88,99};
//        String [] students = {"harry","Sweekrithi","Shreenidhi"};
//        System.out.println(students.length);
       //Displaying the array in for loop
//        for(int i=0;i<marks.length;i++){
//            System.out.println(marks[i]);
//        }
        //To print array in reverse order
        for(int i=marks.length-1;i>=0;i--){
            System.out.println(marks[i]);
        }
        for(int element: marks){
            System.out.println(element);
        }


    }

}
