package com.company;

public class Java_14_LogicalOperators {


        public static void main(String[] args) {
            System.out.println("For Logical AND...");
            boolean a = true;
            boolean b = false;
//        if (a && b){
//            System.out.println("Y");
//        }
//        else{
//            System.out.println("N");
//        }

            System.out.println("For Logical OR...");

//        if (a || b){
//            System.out.println("Y");
//        }
//        else{
//            System.out.println("N");
//        }

            System.out.println("For Logical NOT");
            System.out.print("Not(a) is ");
            System.out.println(!a);
            System.out.print("Not(b) is ");
            System.out.println(!b);
        }
    }



