package com.company;
import java.sql.SQLOutput;
import java.util.Scanner;
import java.util.Random;

public class Java_16_Practice5 {
    public static void main(String[] args) {
//        int a = 11;
//        if(a==11) {
//            System.out.println("I am 11");
//        }
//        else {
//            System.out.println("I am not 11");
//        }
//        System.out.println("Enter marks 1: ");
//        Scanner sc = new Scanner(System.in);
//        int s1 = sc.nextInt();
//        System.out.println("Enter marks 2: ");
//        int s2 = sc.nextInt();
//        System.out.println("Enter marks 3: ");
//        int s3 = sc.nextInt();
//        int total = s1+s2+s3;
//        float t1 = (total * 100)/300f;
//        System.out.println("Your percentage: "+ t1);
//        if(t1>=40 && s1>33 && s2>33 && s3>33){
//            System.out.println("You passed");
//        }
//        else{
//            System.out.println("you failed");
//        }


    //    Scanner sc = new Scanner(System.in);
//        System.out.println("Enter your income in Lakhs per annum");
//        float tax = 0;
//        float income = sc.nextFloat();
//        if(income<=2.5){
//            tax = tax + 0;
//        }
//        else if(income>2.5f && income <= 5f){
//            tax = tax + 0.05f * (income - 2.5f);
//        }
//        else if(income>5f && income <= 10.0f){
//            tax = tax + 0.05f * (5.0f - 2.5f);
//            tax = tax + 0.2f * (income - 5f);
//        }
//        else if(income>10.0f){
//            tax = tax + 0.05f * (5.0f - 2.5f);
//            tax = tax + 0.2f * (10.0f - 5f);
//            tax = tax + 0.3f * (income - 10.0f);
//        }
//
//        Scanner sc = new Scanner(System.in);
////        int day = sc.nextInt();
////
////        switch (day){
////            case 1 -> System.out.println("Monday");
////            case 2 -> System.out.println("Tuesday");
////            case 3 -> System.out.println("Wednesday");
////            case 4 -> System.out.println("Thursday");
////            case 5 -> System.out.println("Friday");
////            case 6 -> System.out.println("Saturday");
////            case 7 -> System.out.println("Sunday");
//        }

//        Scanner sc = new Scanner(System.in);
//      String website = sc.next();
//      if(website.endsWith(".org")){
//          System.out.println("This is an organizational website");
//       }
//      else if(website.endsWith(".com")){
//           System.out.println("This is a Commercial website");
//      }
//       else if(website.endsWith(".in")){
//            System.out.println("This is an Indian website");
//      }
//        Random r = new Random();
//        int a = r.nextInt();
//        System.out.println(a);



    }
}
