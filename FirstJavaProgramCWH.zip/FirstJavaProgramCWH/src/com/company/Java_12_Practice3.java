package com.company;

public class Java_12_Practice3 {
    public static void main(String[] args) {
        String name = "Harry ";
//        name = name.toLowerCase();
        System.out.println(name.toLowerCase());
        System.out.println(name.replace(' ', '_'));
        String name1 = "Dear <|name|>, Trans a lot";
        System.out.println(name1.replace("<|name|>","Sweekrithi"));
        System.out.println(name.indexOf(" "));
        System.out.println("\"Dear Harry,This Java course is nice Thanks\" ");

    }
}



