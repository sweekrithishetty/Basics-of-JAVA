package com.company;
import java.util.Scanner;

public class Java_09_Practice2 {
    public static void main(String[] args) {
//        float a = 7/4.0f * 9/2.0f;
//        System.out.println(a);
        //Encrypt
//        char grade = 'B';
//        grade = ( char)(grade + 8) ;
//        System.out.println(grade);
//
//        //Decrypting the grade
//        grade = ( char)(grade - 8) ;
//        System.out.println(grade);
        //Question 3
//        System.out.println("Enter number 1 : ");
//        Scanner sc = new Scanner(System.in);
//        int n1 = sc.nextInt();
//        System.out.println("Enter number 2 : ");
//        int n2 = sc.nextInt();
//        boolean n3 = n1>n2;
//        boolean n4 = n1<n2;
//        boolean n5 = n1==n2;
//        System.out.println(n3||n4||n5);

        //question 4
//        System.out.println("Enter number v: ");
//        Scanner sc = new Scanner(System.in);
//        int n1 = sc.nextInt();
//        System.out.println("Enter number u: ");
//        int n2  = sc.nextInt();
//        System.out.println("Enter number a: ");
//        int n3  = sc.nextInt();
//        System.out.println("Enter number s: ");
//        int n4  = sc.nextInt();
//        float n5 = (n1*n1 - n2*n2)/(2*n3*n4);
//        System.out.println(n5);

        //question 5
        int x = 7;
        float a = (7*49)/7f + 35/7f;
        System.out.println(a);


    }


}
