package com.company;

public class Java_21_P6 {
    public static void main(String[] args) {
        //Problem Question 1
//        int n =4;
//        for(int i=n;i>0;i--) {
//            for (int j = 0; j <i ; j++) {
//                System.out.print("*");
//
//           }
//            System.out.print("\n");
//        }
        //Problem Question 2
//        int sum =0;
//        int n = 10;
//        for(int i =0 ;i<n;i++){
//            sum = sum + (2*i);
//        }
//        System.out.println("Sum of the natural numbers: ");
//        System.out.println(sum);

//Problem Question 3


    //          int n = 5;
    //          for(int i = 0;i<=10;i++){
    //              System.out.printf("%d x %d = %d\n",n,i,n*i);
    //
    //          }
        // Practice Problem 4
//        int n = 10;
//        //for(int i=0; i<10; i++){- Goes from i=0 to i=9
//        for(int i=10;i>=1;i--){
//            System.out.printf("%d X %d = %d\n", n, i, n*i);
//        }
       // Practice Problem 6
//     int n = 5;
//       int i = 1;
//       int factorial = 1;
//     while(i<=n){
//       factorial *= i;
//          i++;
//      }
//       System.out.println(factorial);



    }
}
