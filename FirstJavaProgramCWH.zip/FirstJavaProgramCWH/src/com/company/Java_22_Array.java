package com.company;

public class Java_22_Array {
    public static void main(String[] args) {
        //there are  3 ways to declare array
//        int [] marks;
//        marks = new int[5];
//        //int [] marks=new int[5];
//        marks[0]=1;
//        marks[1]=2;
//        System.out.println(marks[1]);
        int[] marks = {1,33,2,4};
        System.out.println(marks[3]);

    }
}
