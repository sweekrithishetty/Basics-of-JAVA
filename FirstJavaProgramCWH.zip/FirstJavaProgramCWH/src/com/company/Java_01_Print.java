package com.company;

public class Java_01_Print {

    public static void main(String[] args) {
	// write your code here
        System.out.println("Hello World");
        int num1 = 4;
        int num2 =5;
        int num3 = 7;
        int sum = num1+num2+num3;
                System.out.println(sum);

    }
}
//add two_number
//AddTwoNumber -->pascal naming convention
//addTwoNumber -->camel case naming convention(functions)

